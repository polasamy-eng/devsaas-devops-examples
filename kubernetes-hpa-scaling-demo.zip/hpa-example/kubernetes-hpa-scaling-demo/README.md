# Kubernetes HPA Scaling Demo

Companion code for **[Kubernetes HPA Not Scaling Down](https://devsaas.dev/blog/kubernetes-hpa-not-scaling-down)** on devsaas.dev.

A runnable, minimal setup to reproduce — and fix — the most common "HPA won't scale down" symptom: a missing or default `behavior.scaleDown` policy that makes the autoscaler wait far longer than expected after load actually drops.

## What's here

- `deployment.yaml` — a small CPU-bound demo app + Service
- `hpa.yaml` — an HPA with an explicit `scaleDown.stabilizationWindowSeconds` and scaling policy, instead of relying on the (much slower-feeling) defaults
- `generate-load.sh` — spins up a temporary pod that hammers the Service so you can watch the HPA actually react

## Run it

```bash
kubectl apply -f deployment.yaml
kubectl apply -f hpa.yaml

# in one terminal, watch the HPA live
kubectl get hpa hpa-demo-app -w

# in another terminal, generate load
chmod +x generate-load.sh
./generate-load.sh
```

Let it scale up, then `Ctrl+C` the load generator (or delete the `load-generator` pod) and keep watching `kubectl get hpa -w`. With the `behavior` block in `hpa.yaml`, scale-down kicks in within the configured 120s stabilization window instead of sitting at peak replica count far longer than the load actually lasted.

## The core lesson

If you strip out the `behavior.scaleDown` block entirely, Kubernetes falls back to a default 300-second stabilization window — and that window resets on every metric sample that's still above target, which is why scale-down can feel like it's "stuck" even though it's technically working as designed. Setting this explicitly, rather than trusting the default, is the fix covered in the full article.

For the complete breakdown — including how to tell a genuinely stuck HPA apart from one that's just conservatively configured — see the [full article](https://devsaas.dev/blog/kubernetes-hpa-not-scaling-down).
