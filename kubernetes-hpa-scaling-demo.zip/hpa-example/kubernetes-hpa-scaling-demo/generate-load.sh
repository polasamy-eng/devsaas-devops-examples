#!/bin/bash
# Spins up a temporary busybox pod that hammers the demo Service with requests,
# so you can watch `kubectl get hpa -w` scale up, then watch it (correctly)
# scale back down once you kill this and the stabilization window passes.
#
# Usage: ./generate-load.sh

kubectl run -i --tty load-generator --rm --image=busybox:1.36 --restart=Never -- \
  /bin/sh -c "while sleep 0.01; do wget -q -O- http://hpa-demo-app.default.svc.cluster.local; done"
